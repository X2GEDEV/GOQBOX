-- UI -> game (replaces mp.trigger / mp.triggerServer / mp.invoke)
-- Handlers: AddEventHandler('gs:ui:<eventName>', function(...) end)  (client side)
--           AddEventHandler('gs:srv:<eventName>', function(src, ...) end) (server side, see server.lua)

local opened = false

RegisterNUICallback('trigger', function(data, cb)
  local args = data.args or {}
  if data.name == 'efwd' then
    local name = table.remove(args, 1)
    TriggerServerEvent('gs:ui:server', name, table.unpack(args))
  else
    TriggerEvent('gs:ui:' .. data.name, table.unpack(args))
  end
  cb('ok')
end)

RegisterNUICallback('triggerServer', function(data, cb)
  print('[my_ui] NUI -> client:', data.name)
  TriggerServerEvent('gs:ui:server', data.name, table.unpack(data.args or {}))
  cb('ok')
end)

RegisterNUICallback('invoke', function(data, cb)
  TriggerEvent('gs:ui:invoke:' .. data.name, table.unpack(data.args or {}))
  cb('ok')
end)

-- game -> UI (replaces gui.setData / gui.dispatch). `data` is a normal Lua table/string/number.
local function setData(fnc, data) SendNUIMessage({ action = 'setData', fnc = fnc, data = data }) end
local function dispatch(fnc, data) SendNUIMessage({ action = 'dispatch', fnc = fnc, data = data }) end

local function openPage(page)
  opened = true
  SetNuiFocus(true, true)
  setData('setPage', page)
  return true
end

local function close()
  opened = false
  SetNuiFocus(false, false)
  setData('setPage', '')
end

exports('setData', setData)
exports('dispatch', dispatch)
exports('openPage', openPage)
exports('close', close)

-- Startup: hide GS loading layer + HUD, use Georgian
CreateThread(function()
  Wait(1500)
  setData('setLoadScreen', false)
  setData('hud/showHud', false)
  dispatch('localization/setLang', 'ge')
end)

-- Test command: /gsui Auth | CharacterSelect | SpawnSelect | (no arg = close)
RegisterCommand('gsui', function(_, args)
  local page = args[1]
  if not page then close() return end
  setData('setLoadScreen', false)
  if page:lower() == 'auth' then
    page = 'Auth'
    setData('auth/setSocialClub', { name = 'test' })
    setData('auth/setCurrentTab', { page = 'LoginTab' })
  end
  openPage(page)
end)

RegisterNUICallback('log', function(data, cb)
  print('[my_ui:nui] ' .. tostring(data.msg))
  cb('ok')
end)