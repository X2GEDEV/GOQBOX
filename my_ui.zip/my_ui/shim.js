// RAGE MP -> FiveM NUI bridge. Lets the GS Vue UI run unchanged.
(function () {
  var RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'my_ui';
  var realFetch = window.fetch.bind(window);

  function post(name, data) {
    return realFetch('https://' + RES + '/' + name, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
      body: JSON.stringify(data || {})
    }).catch(function () {});
  }

  // Translations: served from our own locales/<lang>.json (old GS server is gone)
  window.fetch = function (url, opts) {
    var u = String(url);
    if (u.indexOf('/api/localize/list') !== -1) {
      return Promise.resolve(new Response(JSON.stringify({ ge: 'ქართული' }), { status: 200 }));
    }
    var m = u.match(/\/api\/localize\/([a-z]+)$/);
    if (m) {
      return realFetch('locales/' + m[1] + '.json').then(function (r) {
        return r.ok ? r : realFetch('locales/ge.json');
      });
    }
    return realFetch(url, opts);
  };

  window.mp = {
    trigger: function (name) { post('trigger', { name: name, args: [].slice.call(arguments, 1) }); },
    triggerServer: function (name) { post('triggerServer', { name: name, args: [].slice.call(arguments, 1) }); },
    invoke: function (name) { post('invoke', { name: name, args: [].slice.call(arguments, 1) }); },
    events: { _h: {}, add: function (n, f) { this._h[n] = f; } }
  };

  // Lua cannot put nil into arrays; the string "__null__" becomes a real null.
  function fixNull(v) {
    if (v === '__null__') return null;
    if (Array.isArray(v)) return v.map(fixNull);
    if (v && typeof v === 'object') {
      Object.keys(v).forEach(function (k) { v[k] = fixNull(v[k]); });
    }
    return v;
  }

  window.addEventListener('message', function (e) {
    var d = e.data || {};
    try {
      if (d.action === 'setData' && window.setData) window.setData(d.fnc, fixNull(d.data));
      else if (d.action === 'dispatch' && window.dispatch) window.dispatch(d.fnc, fixNull(d.data));
      else if (d.action === 'event' && window.mp.events._h[d.name]) window.mp.events._h[d.name].apply(null, d.args || []);
    } catch (err) {
      post('log', { msg: 'ERR ' + d.fnc + ': ' + err });
    }
    if (d.fnc === 'setPage' || String(d.fnc).indexOf('characterSelect') === 0) {
      setTimeout(function () {
        var el = document.getElementById('app');
        var vm = el && el.__vue__;
        post('log', { msg: d.fnc + ' -> page=' + (vm && vm.$store.state.currentPage) });
      }, 150);
    }
  });

  // Always hide the GS "LOADING" layer once the app is ready.
  var tries = 0;
  var t = setInterval(function () {
    tries++;
    if (window.setData) {
      window.setData('setLoadScreen', false);
      clearInterval(t);
    } else if (tries > 60) {
      clearInterval(t);
    }
  }, 250);
})();
