RegisterNetEvent('gs:ui:server', function(name, ...)
  print(('[my_ui] UI event "%s" from %s'):format(tostring(name), source))
  TriggerEvent('gs:srv:' .. tostring(name), source, ...)
end)