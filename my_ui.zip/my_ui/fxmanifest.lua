fx_version 'cerulean'
game 'gta5'
lua54 'yes'

ui_page 'index.html'

files {
  'index.html', 'shim.js',
  'css/*.css', 'js/*.js',
  'fonts/**/*', 'locales/*.json', 'sounds/**/*',
  'img/**/*'
}

client_scripts { 'client.lua' }
server_scripts { 'server.lua' }
